var bricks = [];
var ball;
var bar;
var start;

function setup() {
  createCanvas(400, 400);
  for (var x = 0; x < width; x += 50)
    for (var y = 0; y < 100; y += 50)
      bricks.push(new Brick(x, y));
  for (var x = -25; x < width; x += 50)
    for (var y = 25; y < 100; y += 50)
      bricks.push(new Brick(x, y));
  ball = new Ball(200, 200);
  bar = new Bar(200);

  textAlign(CENTER);
  start = 0;
}

function draw() {
  background(2);

  // Brick Display
  for (var i = 0; i < bricks.length; i++){
    bricks[i].display();
    if (bricks[i].break() == 1) {
      ball.ydir *= -1;
      bricks.splice(i, 1);
    }
  }

  // Ball Functions
  if (start == 1) {
    ball.display();
    ball.bounce();
  }

  // Bar Functions
  if (keyIsPressed) {
    if (keyCode === LEFT_ARROW)
      bar.x -= 3;
    else if (keyCode === RIGHT_ARROW)
      bar.x += 3;
  }
  bar.display();

  // Start the Game
  if (start == 0)
    StartButton();
}

function Brick(x, y) {
  this.x = x;
  this.y = y;

  this.display = function() {
  stroke(0);
  fill(100, 900, 800);
   rect(this.x, this.y, 50, 25);
  }

  this.break = function() {
    if (ball.x >= this.x && ball.x <= this.x + 50 && ball.y < this.y + 25 + 10)
      return 1;
  }

}

function Ball(x, y) {
  this.x = x;
  this.y = y;
  this.xdir = 0;
  this.ydir = 3;

  this.display = function() {
    if (this.x <= 10 || this.x >= width-10) this.xdir *= -1;
    if (this.y <= 10) this.ydir *= -1;
    this.x += this.xdir;
    this.y += this.ydir;
    stroke(150, 0, 0);
    fill(500, 450, 310);
    ellipse(this.x, this.y, 20);
  }

  this.bounce = function() {
    if (this.x >= bar.x - 50 && this.x <= bar.x + 50 && this.y > height - 30) {
      this.ydir *= -1;
      if (keyIsPressed) {
        if (keyCode === LEFT_ARROW)
          ball.xdir -= 1;
        else if (keyCode === RIGHT_ARROW)
          ball.xdir += 1;
      }
    }
  }

}

function Bar(x) {
  this.x = x;

  this.display = function() {
    stroke(0, 0, 150);
    fill(100, 0, 150);
    rect(this.x - 50, height - 25, 100, 20);
  }
}

function StartButton() {
  stroke(0, 150, 0);
  fill(255);
  rect(100, 250, 200, 100);
  textSize(20);
  fill(0, 150, 0);
  text("CLICK TO", 200, 280);
  textSize(40);
  text("START", 200, 330);
}

function mouseClicked() {
  if (mouseX > 100 && mouseX < 300 && mouseY > 250 && mouseY < 350) {
    start = 1;
  }
}